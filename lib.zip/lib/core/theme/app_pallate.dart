import 'package:flutter/material.dart';

class AppPallate {
  static const Color DeepNavy = Color(0x05367B);
  static const Color TurquoiseLagoon = Color(0x40A4D5);
  static const Color SunnySand = Color(0xE1B07E);
  static const Color CaramelGlow = Color(0xE5BE9E);
  static const Color DesertBeige = Color(0xCBC0AD);
}
